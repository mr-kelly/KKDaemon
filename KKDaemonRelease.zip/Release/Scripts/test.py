
import os
for i in range(1000):
	print 'Test Python script....'


os.system('pause')